<?php

    define('HOST', 'localhost');
    define('DBNAME', 'identites');
    define('USER', 'root');
    define('PASSWORD', '');